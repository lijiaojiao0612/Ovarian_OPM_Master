import numpy as np
import collections
import SimpleITK as sitk
from scipy.ndimage.interpolation import zoom
import os, sys
import pandas as pd
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.feature_selection import f_classif, f_regression
from sklearn.feature_selection import SelectKBest, SelectPercentile
from sklearn.metrics import roc_auc_score, confusion_matrix, roc_curve
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

from radiomics import featureextractor

# Load batch file
imgDir = '/shuju'
dirlist = os.listdir(imgDir)[0:]
print(dirlist)


# read images in Nifti format
def loadSegArraywithID(fold, iden):
    path = fold
    pathList = os.listdir(path)

    segPath = [os.path.join(path, i) for i in pathList if ('seg3' in i.lower()) & (iden in i.lower())][0]
    seg = sitk.ReadImage(segPath)
    return seg


# read regions of interest (ROI) in Nifti format
def loadImgArraywithID(fold, iden):
    path = fold
    pathList = os.listdir(path)

    imgPath = [os.path.join(path, i) for i in pathList if ('im' in i.lower()) & (iden in i.lower())][0]
    img = sitk.ReadImage(imgPath)
    return img


featureDict = {}
for ind in range(len(dirlist)):
    path = os.path.join(imgDir, dirlist[ind])
    mask = loadSegArraywithID(path, 'seg3')
    img = loadImgArraywithID(path, 'i')
    params = '/shuju/Paramsescc.yaml'
    extractor = featureextractor.RadiomicsFeatureExtractor(params)
    result = extractor.execute(img, mask)
    key = list(result.keys())
    key = key[1:]

    feature = []
    for jind in range(len(key)):
        feature.append(result[key[jind]])

    featureDict[dirlist[ind]] = feature
    dictkey = key
    print(dirlist[ind])

dataframe = pd.DataFrame.from_dict(featureDict, orient='index', columns=dictkey)
dataframe.to_csv('/shuju/Feature_Radiomics.csv')

