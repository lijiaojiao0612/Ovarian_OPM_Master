getwd()
setwd('D:/shuju/tezhengxuanze')
library(openxlsx)
library(rms)
train_data<-read.xlsx('ROC_TR.xlsx')
train_data<-read.xlsx('ROC_TE.xlsx')
train_data_1=train_data[,-1]
train_label=train_data[,1]
test_data_1=test_data[,-1]
test_label=test_data[,1]

model_log<-glm(train_label~HE4+CA125,data=train_data_1,family = 'binomial')
model_log1<-glm(train_label~radscore,data=train_data_1,family = 'binomial')
model_log2<-glm(train_label~laterality+Thickened.septa+Margin,data=train_data_1,family = 'binomial')
model_log3<-glm(train_label~laterality+Thickened.septa+CA125+radscore,data=train_data_1,family = 'binomial')
pred_train<-predict(model_log,type='response',newdata=train_data_1)
pred_train1<-predict(model_log1,type='response',newdata=train_data_1)
pred_train2<-predict(model_log2,type='response',newdata=train_data_1)
pred_train3<-predict(model_log3,type='response',newdata=train_data_1)



pred_test<-predict(model_log,type='response',newdata=test_data_1)
pred_test1<-predict(model_log1,type='response',newdata=test_data_1)
pred_test2<-predict(model_log2,type='response',newdata=test_data_1)
pred_test3<-predict(model_log3,type='response',newdata=test_data_1)

library('pROC')
roc_train<-roc(train_label,pred_train,levels=c(0,1))
roc_train1<-roc(train_label,pred_train1,levels=c(0,1))
roc_train2<-roc(train_label,pred_train2,levels=c(0,1))
roc_train3<-roc(train_label,pred_train3,levels=c(0,1))

auc<-roc(train_label,pred_train,levels=c(0,1))
auc1<-roc(train_label,pred_train1,levels=c(0,1))
auc2<-roc(train_label,pred_train2,levels=c(0,1))
auc3<-roc(train_label,pred_train3,levels=c(0,1))

#roc.test(auc2,auc3)
auc(roc_train);ci.auc(roc_train);#计算AUC值和置信区间
auc(roc_train1);ci.auc(roc_train1);
auc(roc_train2);ci.auc(roc_train2);
auc(roc_train3);ci.auc(roc_train3);


roc.test(auc,auc5)
roc.test(auc3,auc5)
roc.test(auc6,auc5)


library(PredictABEL)
pmodel_log<-model_log$fitted.values
pmodel_log1<-model_log1$fitted.values
pmodel_log2<-model_log2$fitted.values
pmodel_log3<-model_log3$fitted.values
reclassification(data=train_data,cOutcome = 1,predrisk1=pmodel_log2,predrisk2=pmodel_log3,cutoff = c(0,0.2,0.4,1))
reclassification()


par(omi=c(0.4,0.4,0.4,0.4),lwd=1.6,cex.axis=1.0,cex.lab=1.5)
p1<-plot.roc(roc_train,col="#F58ACE",
             main="ROC curves",legacy.axes=TRUE)



p2<-plot(roc_train1,add=TRUE,col="#1B95FC")
p3<-plot(roc_train2,add=TRUE,col="#E2BF6A")
p4<-plot(roc_train3,add=TRUE,col="#068606")

legend(0.76,0.3,border="black",legend = c("Clinical model: AUC = 0.759","Radiomics model: AUC = 0.830",
                                          "Radiological model: AUC = 0.819","Combined model: AUC = 0.901"),text.font=2,bty="n",col = c("#F58ACE","#1B95FC","#E2BF6A","#068606"),lty=1,lwd=3,cex=0.9)

library(reportROC)
detailROC<-reportROC(gold=train_label,predictor=pred_train3)
a<-detailROC
print(a)
ROC_Result<- roc(train_label, pred_train3,ci = TRUE)
a=coords(ROC_Result, "best")[1] [1,1]
print(a)
prediction=as.character(pred_test3)
prediction[pred_test3 < a ] <- "0" 
prediction[pred_test3 > a ] <- "1"
obs_p=data.frame(prob=prediction,obs=test_label)
table(obs_p,dnn=c("prediction","test_label"))
library(epiR)
data<-as.table(matrix(c(21,10,7,30),nrow=2,byrow=TRUE))
epiR::epi.tests(data,conf.level=0.95,digit=3)




pred.class<- as.integer(pred_test>0.514)
print(cft<-table(pred.class,test_label))



train_data<-read.xlsx('ROC_TR.xlsx')
train_data$e<-factor(train_data$laterality,levels=c(0,1),labels=c("0","1"))
train_data$c<-factor(train_data$Thickened.septa,levels=c(0,1),labels=c("0","1"))
train_data$label<-factor(train_data$label,levels=c(0,1),labels=c("Without OPM","With OPM"))
dd=datadist(train_data)
options(datadist="dd")
formula1<-as.formula(label~laterality+Thickened.septa+CA125+radscore)
fit1<-lrm(formula1,data=train_data,x=T,y=T)
nom<-nomogram(fit1,
              fun=plogis,
              lp=F,
              fun.at=c(0.05,0.2,0.4,0.6,0.8,0.95),
              funlabel = 'label')
plot(nom)
library(rmda)
train_data<-read.xlsx('ROC_TR.xlsx')

train_data_1=train_data[,-1]
train_label=train_data[,1]
Clinical<-decision_curve(label~HE4+CA125,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
Radscore<-decision_curve(label~radscore,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
Radiological<-decision_curve(label~laterality+Thickened.septa+Margin,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
Nomogram<-decision_curve(label~laterality+Thickened.septa+CA125+radscore,
                         data=train_data,family=binomial(link='logit'),
                         thresholds=seq(0,1,by=0.01),
                         confidence.intervals=0.95,
                         study.design='cohort')
List<- list(Clinical,Radscore,Radiological,Nomogram)
plot_decision_curve(List,curve.names= c('Clinical model','Radiomics model','Radiological model','Combined model'),
                    cost.benefit.axis =FALSE,col = c('red','blue','yellow','#164243'),
                    confidence.intervals =FALSE,standardize = FALSE)


train_data<-read.xlsx('ROC_TR.xlsx')
train_data$laterality<-factor(train_data$laterality,levels=c(0,1),labels=c("0","1"))
train_data$Thickened.septa<-factor(train_data$Thickened.septa,levels=c(0,1),labels=c("0","1"))
train_data$label<-factor(train_data$label,levels=c(0,1),labels=c("Without OPM","With OPM"))
dd=datadist(train_data)
options(datadist="dd")
formula1<-as.formula(label~laterality+Thickened.septa+CA125+radscore)



fit1<-lrm(formula1,data=train_data,x=TRUE,y=TRUE)
cal1<-calibrate(fit1,method = "boot",B=40)
tiff(file = "area_female_train.tiff",width=9.5,height=10,units="in", compression="lzw", res=600);
plot(cal1,
     xlim=c(0,1),
     xlab="Predicted Probability",#label
     ylab="Observed Probability",
     legend=FALSE,
     subtitles=FALSE)
abline(0,1,col="black",lty=2,lwd=1.8)
lines(cal1[,c("predy","calibrated.orig")],type="l",lwd=2,col="red",pch=16)
lines(cal1[,c("predy","calibrated.corrected")],type="l",lwd=2,col="blue",pch=16)
legend(0.6,0.1,              
       c("Ideal"),   
       lty=2,
       lwd=c(2,1,1),
       col=c("black"),
       bty="n",xpd=TRUE)   
legend(0.6,0.2,              
       c("Apparent"),   
       lty=1,
       lwd=c(2,1,1),
       col=c("red"),
       bty="n",xpd=TRUE)   
legend(0.6,0.3,              
       c("Bias-corrected"),   
       lty=1,
       lwd=c(2,1,1),
       col=c("blue"),
       bty="n",xpd=TRUE) 
dev.off()
ckf
library(ResourceSelection)
hl<-hoslem.test(fit1$train_label,fitted(fit1),g=10)
