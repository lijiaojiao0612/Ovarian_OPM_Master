getwd()
setwd('D:/shuju/tezhengshaixuan')
getwd()

install.packages('rms')

install.packages('openxlsx')
library(openxlsx)
library(rms)

data<-read.xlsx('radiomics_feature.xlsx')

dimension<-dim(data)
dimension
set.seed(1234)
training_index <- sample(1:224, 0.7 * 224, replace = F)
validation_index <- c(1:224)[-training_index]
training_index
validation_index
training_set <- data[training_index, ]
validation_set <- data[validation_index, ]


training_set_nolabel<-training_set[,-1]
training_set_label<-training_set[,1]
validation_set_nolabel<-validation_set[,-1]
validation_set_label<--validation_set[,1]


install.packages('caret')
library(caret)
dim(training_set_nolabel)
dim(validation_set_nolabel)

normal_para<-preProcess(x=training_set_nolabel,method=c("center","scale"))
training_set_nolabel_normal<-predict(object=normal_para,newdata=training_set_nolabel)
validation_set_nolabel_normal<-predict(object = normal_para,newdata=validation_set_nolabel)



norm_result<-apply(training_set_nolabel,2,function(x)shapiro.test(x)$p.value)
norm_feature<-training_set_nolabel[which(norm_result>=0.05)]
cor_nor<-cor(norm_feature,method = 'pearson')
cor_all<-cor(training_set_nolabel,method='spearman')
num_nor<-dim(cor_nor)[1]
cor_all[1:num_nor,1:num_nor]<-cor_nor
cor_all[upper.tri(cor_all)]<-0
diag(cor_all)<-0
data_reduce=training_set_nolabel[,!apply(cor_all,2,function(x) any(abs(x)>0.9))]
dim(data_reduce)
View(data_reduce)

install.packages('glmnet')
library(glmnet)
cv_x<-as.matrix(training_set_nolabel_normal)
cv_y<-training_set_label
View(cv_y)

set.seed(1)
lasso_selection<-cv.glmnet(x=cv_x,
                           y=cv_y,
                           family="binomial",
                           type.measure="deviance",
                           alpha=1,
                           nfolds=10)
coefPara<-coef(object=lasso_selection,s="lambda.min")
lasso_values<-as.data.frame(which(coefPara!=0,arr.ind = T))
lasso_names<-rownames(lasso_values)[-1]
lasso_coef<-data.frame(Feature=rownames(lasso_values),
                       Coef=coefPara[which(coefPara!=0,arr.ind = T)])
lasso_coef
print(lasso_coef)

lasso_selection$lambda.min
log(lasso_selection$lambda.min)
par(font.lab=2,mfrow=c(2,1),mar=c(4.5,5,3,2))
plot(x=lasso_selection,las=1,xlab="Log(lambda)")

nocv_lasso<-glmnet(x=cv_x,y=cv_y,family="binomial",alpha=1)
plot(nocv_lasso,xvar="lambda",las=1,lwd=2,xlab="Log(lambda)")
abline(v=log(lasso_selection$lambda.min),lwd=1,lty=3,col="black")
abline(v=log(lasso_selection$lambda.1se),lwd=1,lty=3,col="black")


